import React from 'react';
import {Outlet} from "react-router-dom";

function Layout(props) {
    return (<>
        <Outlet></Outlet>
    </>

    );
}

export default Layout;