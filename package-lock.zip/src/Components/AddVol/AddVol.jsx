import React, { useState } from 'react';
import {useNavigate} from "react-router-dom";

function AddVol({ listAeroport }) {
    listAeroport=["morocco","algeria","senegal","france"]
    let  listPlans=["air plan 1","air plan 2","air plan 3","air plan 4"]
    const [departureAirport, setDepartureAirport] = useState('');
    const [arrivalAirport, setArrivalAirport] = useState('');
    const [airplan,setAirplan] =useState('')
    let Navigate =useNavigate();
    const handleDepartureChange = (event) => {
        setDepartureAirport(event.target.value);
    };

    const handleArrivalChange = (event) => {
        setArrivalAirport(event.target.value);
    };
    const handleSelectedPlan=(event)=>{
        setAirplan(event.target.value)
    }
    function switchToSimulator(){
        Navigate("/simulation");
    }

    return (
        <div>
            <h4>Choisir l'aéroport de départ</h4>
            <select
                id="departureAirport"
                name="departureAirport"
                value={departureAirport}
                onChange={handleDepartureChange}
            >
                {listAeroport.length > 0 ? (
                    <>
                        <option value={listAeroport[0]}>{listAeroport[0]}</option>
                        {listAeroport.slice(1).map((item, index) => (
                            <option key={index} value={item}>
                                {item}
                            </option>
                        ))}
                    </>
                ) : null}
            </select>

            <h4>Choisir l'aéroport d'arrivée</h4>
            <select id="arrivalAirport"
                name="arrivalAirport"
                value={arrivalAirport}
                onChange={handleArrivalChange}
            >
                {listAeroport.length > 0 ? (
                    <>
                        <option value={listAeroport[0]}>{listAeroport[0]}</option>
                        {listAeroport.slice(1).map((item, index) => (
                            <option key={index} value={item}>
                                {item}
                            </option>
                        ))}
                    </>
                ) : null}
            </select>
            <h4>Choisir l'avion</h4>
            <select id="listPlans"
                    name="listPlans"
                    value={airplan}
                    onChange={handleSelectedPlan}
            >
                {listPlans.length > 0 ? (
                    <>
                        <option value={listPlans[0]}>{listPlans[0]}</option>
                        {listPlans.slice(1).map((item, index) => (
                            <option key={index} value={item}>
                                {item}
                            </option>
                        ))}
                    </>
                ) : null}
            </select>
            <h4>choose the airplane</h4>

            <p>Selected departure airport: {departureAirport}</p>
            <p>Selected arrival airport: {arrivalAirport}</p>
            <p>Selected airplan: {airplan}</p>
            <button onClick={switchToSimulator}>to</button>
        </div>
    );
}

export default AddVol;
