import React, {useEffect, useState} from 'react';
import Style from "./Simulation.module.css"
import Card from "../Card/Card";
import axios from "axios";


    function Simulation(props) {
        let [aeroport, setAeroport] = useState([]);

        useEffect(() => {
            async function fetchData() {
                try {
                    const result = await axios.get("http://localhost:8080/aeroports/listaeroport");

                    setAeroport(result.data);

                    console.log(aeroport);
                } catch (error) {
                    console.error("Error fetching data:", error);
                }
            }
            fetchData();
        }, []);


    return (
        <div className={Style.main +" position-relative"}>
            <div className="position-absolute" style={{bottom:"0",left:"23%"}}>
                <Card info={aeroport[0]}/>
            </div>
            <div className="position-absolute" style={{top:"230px",left:"40%"}}>
                <Card info={aeroport[1]}/>
            </div>
            <div className="position-absolute" style={{top:"180px",left:"100px"}}>
                <Card  info={aeroport[2]} />
            </div>
            <div className="position-absolute" style={{top:"50%",right:"250px"}}>
                <Card  info={aeroport[3]}/>
            </div>
        </div>
    );
}

export default Simulation;