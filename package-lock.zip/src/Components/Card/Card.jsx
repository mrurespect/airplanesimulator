import React, {useState} from 'react';


function Card({ info }) {
    let [display, setDisplay] = useState(true);

    console.log("nom : " + (info ? info.nom : "N/A"));

    function affiche() {
        if (display === false) {
            setDisplay(true);
            console.log(true);
        } else {
            setDisplay(false);
            console.log(false);
        }
    }

    return (
        <div className="bg-primary rounded" style={{ width: "fit-content", height: "fit-content" }}>
            <button className="btn btn-outline-info w-100 px-5 border-0" onClick={affiche}>{info ? info.nom : "N/A"}</button>
            <div className={"p-3 " + (display ? "d-none" : "")}>
                <p>name : <span>{info ? info.nom : "N/A"}</span></p>
                <p>nombre de piste : <span>{info ? info.nombrePiste : "N/A"}</span></p>
                <p>attente sol : <span>{info ? info.attenteSol : "N/A"}</span></p>
                <p>acces piste : <span>{info ? info.accesPiste: "N/A"}</span></p>
            </div>
        </div>
    );
}

export default Card;
;