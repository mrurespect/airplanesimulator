
import './App.css';
import Simulation from "./Components/Simulation/Simulation";
import AddVol from "./Components/AddVol/AddVol";
import {createBrowserRouter, RouterProvider} from "react-router-dom";
import Layout from "./Components/Layout/Layout";

function App() {
    let routers = createBrowserRouter([
        {path:"/",element:<Layout/>,children:[
                {element: <Simulation/>, path: "/simulation"},
                { index:true,element: <AddVol/> }
            ]}
        ]

    )

    return (
        <RouterProvider router={routers}/>
    )
}
export default App;
